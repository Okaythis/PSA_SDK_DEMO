//
//  PSAAttestationLoadingViewController.h
//  DefaultPsaUi
//
//  Created by Satheesh Kannan on 07/03/23.
//  Copyright © 2023 Protectoria. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface PSAAttestationLoadingViewController : UIViewController

+ (PSAAttestationLoadingViewController *)create;

@property(nonatomic, weak) IBOutlet UIActivityIndicatorView *activityIndicator;

@end

NS_ASSUME_NONNULL_END
