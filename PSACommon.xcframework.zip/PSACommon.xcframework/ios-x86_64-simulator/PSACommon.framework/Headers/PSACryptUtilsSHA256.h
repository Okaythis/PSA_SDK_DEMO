//
//  PSACryptUtilsSHA256.h
//  PSACommon
//
//  Created by Satheesh Kannan on 02/02/23.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface PSACryptUtilsSHA256 : NSObject

+ (NSData *)sha256HashForText:(NSString *)text;

@end

NS_ASSUME_NONNULL_END
